print("Lorem Impusum")
